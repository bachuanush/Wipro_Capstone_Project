//package Step_Definition;
//
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class Search_Step {
//
//@Given("login user and search button available")
//public void login_user_and_search_button_available() {
//
//}
//
//@When("click on search button")
//public void click_on_search_button() {
//
//}
//
//@When("Enter inputs and then use keyboard enter key")
//public void enter_inputs_and_then_use_keyboard_enter_key() {
//
//}
//
//@Then("List of output relevant to inputs")
//public void list_of_output_relevant_to_inputs() {
//
//}
//}
